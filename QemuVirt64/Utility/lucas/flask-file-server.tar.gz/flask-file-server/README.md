# Fresh repo

## Install virtual env and app dependencies
cd <project-dir>
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt


# Working repo

## Run the server
cd <project-dir>
. venv/bin/activate
python3 serv_files.py
