# Development

Steps to bootstrap a development DB instance:

1. Install MariaDB (10.4 series) on your development PC.

	Tip: for Ubuntu 18.04:

	To install MariaDB 10.4:
	https://computingforgeeks.com/install-mariadb-10-on-ubuntu-18-04-and-centos-7/

	To reset root password:
	https://websiteforstudents.com/mariadb-installed-without-password-prompts-for-root-on-ubuntu-17-10-18-04-beta/ 


2. Install DB schema

```
cd <repo-root>/dev
skeema push development -p
```

