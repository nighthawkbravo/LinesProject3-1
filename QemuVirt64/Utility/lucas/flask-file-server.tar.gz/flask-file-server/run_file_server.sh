cd /root/flask-file-server
. venv/bin/activate
python3 serv_files.py &
